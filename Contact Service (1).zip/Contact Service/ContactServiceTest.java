package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAddContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact(
				"12345", "John", "Smith",
				"6035551234", "123 Main Street"
		);
		
		service.addContact(contact);
		
		assertEquals(contact, service.getContact("12345"));
	}
	
	@Test
	void testDeleteContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact(
				"12345", "John", "Smith",
				"6035551234", "123 Main Street"
		);
		
		service.addContact(contact);
		service.deleteContact("12345");
		
		assertNull(service.getContact("12345"));
	}
	
	@Test
	void testUpdateContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact(
				"12345", "John", "Smith",
				"6035551234", "123 Main Street"
		);
		
		service.addContact(contact);
		
		service.updateFirstName("12345", "Jane");
		service.updateLastName("12345", "Jones");
		service.updatePhone("12345", "6035559999");
		service.updateAddress("12345", "456 Oak Street");
		
		assertEquals("Jane", contact.getFirstName());
		assertEquals("Jones", contact.getLastName());
		assertEquals("6035559999", contact.getPhone());
		assertEquals("456 Oak Street", contact.getAddress());
	}
	
	@Test
	void testDuplicateContactId() {
		ContactService service = new ContactService();
		
		Contact contact1 = new Contact(
				"12345", "John", "Smith",
				"6035551234", "123 Main Street"
		);
		
		Contact contact2 = new Contact(
				"12345", "Jane", "Jones",
				"6035555678", "456 Oak Street"
		);
		
		service.addContact(contact1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact2);
		});
	}
}
