package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact(
				"12345",
				"John",
				"Smith",
				"6035551234",
				"123 Main Street"
		);
		
		assertEquals("12345", contact.getContactId());
		assertEquals("John", contact.getFirstName());
		assertEquals("Smith", contact.getLastName());
		assertEquals("6035551234", contact.getPhone());
		assertEquals("123 Main Street", contact.getAddress());
	}
	
	@Test
	void testInvalidContactId() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"12345678901",
					"John",
					"Smith",
					"6035551234",
					"123 Main Street"
			);
		});
	}
	
	@Test
	void testInvalidPhone() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact(
					"12345",
					"John",
					"Smith",
					"12345",
					"123 Main Street"
			);
		});
	}
}
