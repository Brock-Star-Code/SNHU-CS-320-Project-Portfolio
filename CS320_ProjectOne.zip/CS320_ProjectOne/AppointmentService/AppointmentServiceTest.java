package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	@Test
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("1", futureDate, "Doctor appointment");
		
		service.addAppointment(appointment);
		
		assertEquals(appointment, service.getAppointment("1"));
	}
	
	@Test
	void testDuplicateId() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		
		Appointment appointment1 =
				new Appointment("1", futureDate, "First appointment");
		Appointment appointment2 =
				new Appointment("1", futureDate, "Second appointment");
		
		service.addAppointment(appointment1);
		
		assertThrows(IllegalArgumentException.class, () ->
		        service.addAppointment(appointment2));
	}
	
	@Test
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("1", futureDate, "Doctor appointment");
		
		service.addAppointment(appointment);
		service.deleteAppointment("1");
		
		assertNull(service.getAppointment("1"));
		
		assertThrows(IllegalArgumentException.class, () ->
		    service.deleteAppointment("1"));
	}
	
	@Test
	void testDeleteInvalidId() {
		AppointmentService service = new AppointmentService();
		
		assertThrows(IllegalArgumentException.class, () ->
		        service.deleteAppointment("1"));
	}
}
