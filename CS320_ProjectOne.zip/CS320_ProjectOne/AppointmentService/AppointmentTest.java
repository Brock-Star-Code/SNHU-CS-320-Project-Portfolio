package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void testAppointment() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Doctor appointment");
		
		assertEquals("123", appointment.getAppointmentId());
		assertEquals(futureDate, appointment.getAppointmentDate());
		assertEquals("Doctor appointment", appointment.getDescription());
	}
	
	@Test
	void testAppointmentIdTooLong() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		
		assertThrows(IllegalArgumentException.class, () ->
		        new Appointment("12345678901", futureDate, "Appointment"));
	}
	
	@Test
	void testAppointmentIdNull() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		
		assertThrows(IllegalArgumentException.class, () ->
		        new Appointment(null, futureDate, "Appointment"));
	}
	
	@Test
	void testAppointmentDatePast() {
		Date pastDate = new Date(System.currentTimeMillis() - 86400000);
		
		assertThrows(IllegalArgumentException.class, () ->
		        new Appointment("12345678901", pastDate, "Appointment"));
	}
	
	@Test
	void testAppointmentDateNull() {
		assertThrows(IllegalArgumentException.class, () ->
		        new Appointment("123", null, "Appointment"));
	}
	
	@Test
	void testDescriptionTooLong() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		
		assertThrows(IllegalArgumentException.class, () ->
		        new Appointment("12345678901", futureDate, "123456789012345678901234567890123456789012345678901"));
	}
	
	@Test
	void testDescriptionNull() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		
		assertThrows(IllegalArgumentException.class, () ->
		        new Appointment("123", futureDate, null));
	}
	
	@Test
	void testBoundaries() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		
		Appointment appointment = new Appointment(
				"1234567890",
				futureDate,
				"12345678901234567890123456789012345678901234567890");
		
		assertEquals(10, appointment.getAppointmentId().length());
		assertEquals(50, appointment.getDescription().length());
	}
	
	@Test
	void testSetAppointmentDate() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Appointment");
		
		Date newDate = new Date(System.currentTimeMillis() + 172800000);
		appointment.setAppointmentDate(newDate);
		
		assertEquals(newDate, appointment.getAppointmentDate());
	}
	
	@Test
	void testSetAppointmentDatePast() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Appointment");
		
		Date pastDate = new Date(System.currentTimeMillis() - 86400000);
		
		assertThrows(IllegalArgumentException.class, () ->
		        appointment.setAppointmentDate(pastDate));
	}
	
	@Test
	void testSetAppointmentDateNull() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Appointment");
		
		assertThrows(IllegalArgumentException.class, () ->
		        appointment.setAppointmentDate(null));	
	}
	
	@Test
	void testSetDescription() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Appointment");
		
		appointment.setDescription("New appointment");
		
		assertEquals("New appointment", appointment.getDescription());
	}
	
	@Test
	void testSetDescriptionTooLong() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Appointment");
		
		assertThrows(IllegalArgumentException.class, () ->
		        appointment.setDescription(
		        		"123456789012345678901234567890123456789012345678901"));
	}
	
	@Test
	void testSetDescriptionNull() {
		Date futureDate = new Date(System.currentTimeMillis() + 86400000);
		Appointment appointment =
				new Appointment("123", futureDate, "Appointment");
		
		assertThrows(IllegalArgumentException.class, () ->
		        appointment.setDescription(null));
	}
}
