package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact(
				"12345",
				"John",
				"Smith",
				"6035551234",
				"123 Main Street"
		);
		
		assertEquals("12345", contact.getContactId());
		assertEquals("John", contact.getFirstName());
		assertEquals("Smith", contact.getLastName());
		assertEquals("6035551234", contact.getPhone());
		assertEquals("123 Main Street", contact.getAddress());
	}
	
	@Test
	void testContactIdTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345678901", "John", "Smith",
		    		"6035551234", "123 Main Street"));
	}
	
	@Test
	void testContactIdNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact(null, "John", "Smith",
		    		"6035551234", "123 Main Street"));
	}
	
	@Test
	void testFirstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "JohnJohnJoh",
		    		"Smith", "6035551234", "123 Main Street"));
	}
	
	@Test
	void testFirstNameNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", null,
		    		"Smith", "6035551234", "123 Main Street"));
	}
	
	@Test
	void testLastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "John",
		    		"SmithSmithS", "6035551234", "123 Main Street"));
	}
	
	@Test
	void testLastNameNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "John",
		    		null, "6035551234", "123 Main Street"));
	}
	
	@Test
	void testInvalidPhone() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "John", "Smith",
		    		"12345", "123 Main Street"));
	}
	
	@Test
	void testPhoneNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "John", "Smith",
		    		null, "123 Main Street"));
	}
	
	@Test
	void testAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "John", "Smith",
		    		"6035551234", "1234567890123456789012345678901"));
	}
	
	@Test
	void testAddressNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Contact("12345", "John", "Smith",
		    		"6035551234", null));
	}
	
	@Test
	void testBoundaries() {
		Contact contact = new Contact(
				"1234567890",
				"JohnSmith1",
				"SmithJohn1",
				"6035551234",
				"123456789012345678901234567890"
		);
		
		assertEquals(10, contact.getContactId().length());
		assertEquals(10, contact.getFirstName().length());
		assertEquals(10, contact.getLastName().length());
		assertEquals(10, contact.getPhone().length());
		assertEquals(30, contact.getAddress().length());
	}
}