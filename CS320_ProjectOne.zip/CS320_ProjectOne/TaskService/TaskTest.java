package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void test() {
		Task task = new Task("123", "Homework", "Finish assignment");
		
		assertEquals("123", task.getTaskId());
		assertEquals("Homework", task.getName());
		assertEquals("Finish assignment", task.getDescription());
	}
	
	@Test
	void testTaskIdTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Task("12345678901", "Homework", "Assignment"));
	}
	
	@Test
	void testTaskIdNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Task(null, "Homework", "Assignment"));
	}
	
	@Test
	void testNameTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Task("123", "123456789012345678901", "Assignment"));
	}
	
	@Test
	void testNameNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Task("123", null, "Assignment"));
	}
	
	@Test
	void testDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Task("123", "Homework",
		    	"123456789012345678901234567890123456789012345678901"));
	}
	
	@Test
	void testDescriptionNull() {
		assertThrows(IllegalArgumentException.class, () ->
		    new Task("123", "Homework", null));
	}
	
	@Test
	void testBoundaries() {
		Task task = new Task(
			"1234567890",
			"12345678901234567890",
			"12345678901234567890123456789012345678901234567890");
		
		assertEquals(10, task.getTaskId().length());
		assertEquals(20, task.getName().length());
		assertEquals(50, task.getDescription().length());
	}
	
	@Test
	void testSetNameNull() {
		Task task = new Task("123", "Homework", "Assignment");
		
		assertThrows(IllegalArgumentException.class, () ->
		    task.setName(null));
	}
	
	@Test
	void testSetNameTooLong() {
		Task task = new Task("123", "Homework", "Assignment");
		
		assertThrows(IllegalArgumentException.class, () ->
		    task.setName("123456789012345678901"));
	}
	
	@Test
	void testSetDescriptionNull() {
		Task task = new Task("123", "Homework", "Assignment");
		
		assertThrows(IllegalArgumentException.class, () ->
		    task.setDescription(null));
	}
	
	@Test
	void testSetDescriptionTooLong() {
		Task task = new Task("123", "Homework", "Assignment");
		
		assertThrows(IllegalArgumentException.class, () ->
		    task.setDescription(
		    	"123456789012345678901234567890123456789012345678901"));
	}
}
