package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testAddTask() {
		TaskService service = new TaskService();
		Task task = new Task("1", "Homework", "Assignment");
		
		assertDoesNotThrow(() -> service.addTask(task));
	}
	
	@Test
	void testDuplicateId() {
		TaskService service = new TaskService();
		service.addTask(new Task("1", "Homework", "Assignment"));
		
		assertThrows(IllegalArgumentException.class, () ->
		    service.addTask(new Task("1", "Homework", "Assignment")));
	}
	
	@Test
	void testDeleteTask() {
		TaskService service = new TaskService();
		service.addTask(new Task("1", "Homework", "Assignment"));
		
		assertDoesNotThrow(() -> service.deleteTask("1"));
	}
	
	@Test
	void testUpdateTask() {
		TaskService service = new TaskService();
		Task task = new Task("1", "Homework", "Assignment");
		
		service.addTask(task);
		service.updateTask("1", "Study", "Study for test");
		
		assertEquals("Study", task.getName());
		assertEquals("Study for test", task.getDescription());
	}
	
	@Test
	void testInvalidTaskId() {
		TaskService service = new TaskService();
		
		assertThrows(IllegalArgumentException.class, () ->
	        service.deleteTask("1"));
		
		assertThrows(IllegalArgumentException.class, () ->
		    service.updateTask("1", "Study", "Test"));
	}
}
