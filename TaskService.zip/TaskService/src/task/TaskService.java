package task;

import java.util.ArrayList;

public class TaskService {
	private final ArrayList<Task> tasks = new ArrayList<>();
	
	public void addTask(Task task) {
		for (Task t : tasks) {
			if (t.getTaskId().equals(task.getTaskId()))
				throw new IllegalArgumentException();
		}
		tasks.add(task);
	}
	
	public void deleteTask(String taskId) {
		for (Task task : tasks) {
			if (task.getTaskId().equals(taskId)) {
				tasks.remove(task);
				return;
			}
		}
		throw new IllegalArgumentException(); 
	}
	
	public void updateTask(String taskId, String name, String description) {
		for (Task task : tasks) {
			if (task.getTaskId().equals(taskId)) {
				task.setName(name);
				task.setDescription(description);
				return;
			}
		}
		throw new IllegalArgumentException(); 
	}
}
